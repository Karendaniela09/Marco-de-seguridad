using System;
using MarcoSeguridad.NCapas.Entity;
using MarcoSeguridad.NCapas.Security;

namespace MarcoSeguridad.NCapas.Logic
{
    public class UsuarioLogic
    {
        public Usuario RegistrarUsuario(
            string nombreUsuario,
            string contraseña,
            PoliticaContraseña politica)
        {
            // Validar políticas (marco de seguridad)
            if (!SeguridadHelper.CumplePoliticas(contraseña, politica))
                throw new Exception("La contraseña no cumple las políticas de seguridad.");

            // Encriptar usando codificación negra
            string hash = SeguridadHelper.EncriptarContraseña(contraseña);

            // Crear entidad Usuario
            return new Usuario
            {
                NombreUsuario = nombreUsuario,
                Contraseña = hash,
                EstadoUsuario = true,
                TipoAutenticacion = "SQL",
                FechaCreacion = DateTime.Now
            };
        }

        public bool ValidarLogin(Usuario usuario, string contraseñaIngresada)
        {
            return SeguridadHelper.VerificarContraseña(
                contraseñaIngresada,
                usuario.Contraseña
            );
        }
    }
}
