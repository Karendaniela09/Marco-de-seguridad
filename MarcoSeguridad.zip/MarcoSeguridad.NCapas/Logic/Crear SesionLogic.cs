using MarcoSeguridad.NCapas.Entity;
using MarcoSeguridad.NCapas.Security;

namespace MarcoSeguridad.NCapas.Logic
{
    public class SesionLogic
    {
        public SesionUsuario IniciarSesion(int usuarioID, string ip)
        {
            return SesionHelper.CrearSesion(usuarioID, ip);
        }

        public void CerrarSesion(SesionUsuario sesion)
        {
            SesionHelper.CerrarSesion(sesion);
        }
    }
}
