using System.Data.SqlClient;

namespace MarcoSeguridad.NCapas.Data
{
    public class DbConexion
    {
        private readonly string _cadenaConexion;

        public DbConexion(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
        }

        public SqlConnection ObtenerConexion()
        {
            return new SqlConnection(_cadenaConexion);
        }
    }
}
