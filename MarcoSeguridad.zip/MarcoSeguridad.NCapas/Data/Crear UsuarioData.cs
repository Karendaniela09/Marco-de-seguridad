using System.Data.SqlClient;
using MarcoSeguridad.NCapas.Entity;

namespace MarcoSeguridad.NCapas.Data
{
    public class UsuarioData
    {
        private readonly DbConexion _conexion;

        public UsuarioData(DbConexion conexion)
        {
            _conexion = conexion;
        }

        public void InsertarUsuario(Usuario usuario)
        {
            using (SqlConnection con = _conexion.ObtenerConexion())
            {
                string sql = @"INSERT INTO Usuarios 
                              (NombreUsuario, Contraseña, EstadoUsuario, TipoAutenticacion, FechaCreacion)
                               VALUES (@Nombre, @Pass, @Estado, @Tipo, @Fecha)";

                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@Nombre", usuario.NombreUsuario);
                cmd.Parameters.AddWithValue("@Pass", usuario.Contraseña);
                cmd.Parameters.AddWithValue("@Estado", usuario.EstadoUsuario);
                cmd.Parameters.AddWithValue("@Tipo", usuario.TipoAutenticacion);
                cmd.Parameters.AddWithValue("@Fecha", usuario.FechaCreacion);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public Usuario ObtenerPorNombre(string nombreUsuario)
        {
            using (SqlConnection con = _conexion.ObtenerConexion())
            {
                string sql = "SELECT * FROM Usuarios WHERE NombreUsuario = @Nombre";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@Nombre", nombreUsuario);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    return new Usuario
                    {
                        UsuarioID = (int)dr["UsuarioID"],
                        NombreUsuario = dr["NombreUsuario"].ToString(),
                        Contraseña = dr["Contraseña"].ToString(),
                        EstadoUsuario = (bool)dr["EstadoUsuario"],
                        TipoAutenticacion = dr["TipoAutenticacion"].ToString(),
                        FechaCreacion = (DateTime)dr["FechaCreacion"]
                    };
                }
            }
            return null;
        }
    }
}
