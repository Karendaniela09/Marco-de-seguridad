using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using MarcoSeguridad.NCapas.Entity;

namespace MarcoSeguridad.NCapas.Security
{
    public static class SeguridadHelper
    {
        // Encriptación (codificación negra)
        public static string EncriptarContraseña(string contraseña)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] bytes = Encoding.UTF8.GetBytes(contraseña);
                byte[] hash = sha.ComputeHash(bytes);
                return Convert.ToBase64String(hash);
            }
        }

        // Verificación de contraseña
        public static bool VerificarContraseña(string contraseña, string hash)
        {
            return EncriptarContraseña(contraseña) == hash;
        }

        // Validación de políticas
        public static bool CumplePoliticas(string contraseña, PoliticaContraseña politica)
        {
            if (contraseña.Length < politica.MinLongitud) return false;
            if (contraseña.Length > politica.MaxLongitud) return false;
            if (politica.RequiereMayusculas && !contraseña.Any(char.IsUpper)) return false;
            if (politica.RequiereNumeros && !contraseña.Any(char.IsDigit)) return false;
            if (politica.RequiereSimbolos && !contraseña.Any(c => !char.IsLetterOrDigit(c))) return false;

            return true;
        }
    }
}
