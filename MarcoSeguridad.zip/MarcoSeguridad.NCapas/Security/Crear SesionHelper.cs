using System;
using MarcoSeguridad.NCapas.Entity;

namespace MarcoSeguridad.NCapas.Security
{
    public static class SesionHelper
    {
        public static SesionUsuario CrearSesion(int usuarioID, string ip)
        {
            return new SesionUsuario
            {
                UsuarioID = usuarioID,
                FechaInicio = DateTime.Now,
                IP_Origen = ip,
                EstadoSesion = "Activo"
            };
        }

        public static void CerrarSesion(SesionUsuario sesion)
        {
            sesion.FechaFin = DateTime.Now;
            sesion.EstadoSesion = "Cerrado";
        }
    }
}
