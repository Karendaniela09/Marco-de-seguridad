namespace MarcoSeguridad.NCapas.Entity
{
    public class Usuario
    {
        public int UsuarioID { get; set; }
        public string NombreUsuario { get; set; }
        public string Contraseña { get; set; }
        public bool EstadoUsuario { get; set; }
        public string TipoAutenticacion { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime? UltimoAcceso { get; set; }
    }
}
