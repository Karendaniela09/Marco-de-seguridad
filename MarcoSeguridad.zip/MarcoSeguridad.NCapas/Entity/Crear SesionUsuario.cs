namespace MarcoSeguridad.NCapas.Entity
{
    public class SesionUsuario
    {
        public int SesionID { get; set; }
        public int UsuarioID { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime? FechaFin { get; set; }
        public string IP_Origen { get; set; }
        public string EstadoSesion { get; set; }
    }
}
