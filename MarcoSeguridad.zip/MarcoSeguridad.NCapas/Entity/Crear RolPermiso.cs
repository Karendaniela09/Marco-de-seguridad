namespace MarcoSeguridad.NCapas.Entity
{
    public class RolPermiso
    {
        public int RolID { get; set; }
        public int PermisoID { get; set; }
        public DateTime FechaAsignacion { get; set; }
    }
}
