namespace MarcoSeguridad.NCapas.Entity
{
    public class LogError
    {
        public int ErrorID { get; set; }
        public DateTime Fecha { get; set; }
        public int? UsuarioID { get; set; }
        public string TipoError { get; set; }
        public string Descripcion { get; set; }
        public string IP_Origen { get; set; }
    }
}
