namespace MarcoSeguridad.NCapas.Entity
{
    public class Permiso
    {
        public int PermisoID { get; set; }
        public string NombrePermiso { get; set; }
        public string Descripcion { get; set; }
    }
}
