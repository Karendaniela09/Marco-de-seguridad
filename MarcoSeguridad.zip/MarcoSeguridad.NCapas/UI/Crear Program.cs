using System;
using MarcoSeguridad.NCapas.Entity;
using MarcoSeguridad.NCapas.Logic;
using MarcoSeguridad.NCapas.Data;

namespace MarcoSeguridad.NCapas.UI
{
    class Program
    {
        static void Main(string[] args)
        {
            // Cadena de conexión (ejemplo)
            string cadenaConexion = "TU_CADENA_DE_CONEXION_SQL";

            //  Capa Data
            DbConexion conexion = new DbConexion(cadenaConexion);
            UsuarioData usuarioData = new UsuarioData(conexion);

            // Capa Logic
            UsuarioLogic usuarioLogic = new UsuarioLogic();
            SesionLogic sesionLogic = new SesionLogic();

            //  Política de contraseña (marco de seguridad)
            PoliticaContraseña politica = new PoliticaContraseña
            {
                MinLongitud = 8,
                MaxLongitud = 20,
                RequiereMayusculas = true,
                RequiereNumeros = true,
                RequiereSimbolos = true
            };

            Console.WriteLine("=== REGISTRO DE USUARIO ===");
            Console.Write("Usuario: ");
            string nombre = Console.ReadLine();

            Console.Write("Contraseña: ");
            string pass = Console.ReadLine();

            //  Registrar usuario (Security + Logic)
            Usuario nuevoUsuario = usuarioLogic.RegistrarUsuario(nombre, pass, politica);

            // Guardar en BD (Data)
            usuarioData.InsertarUsuario(nuevoUsuario);
            Console.WriteLine("Usuario registrado correctamente\n");

            // Login
            Console.WriteLine("=== INICIO DE SESIÓN ===");
            Console.Write("Usuario: ");
            string loginUser = Console.ReadLine();

            Console.Write("Contraseña: ");
            string loginPass = Console.ReadLine();

            Usuario usuarioBD = usuarioData.ObtenerPorNombre(loginUser);

            if (usuarioBD != null && usuarioLogic.ValidarLogin(usuarioBD, loginPass))
            {
                Console.WriteLine("Login exitoso");

                // Crear sesión
                var sesion = sesionLogic.IniciarSesion(usuarioBD.UsuarioID, "127.0.0.1");
                Console.WriteLine("Sesión iniciada");
            }
            else
            {
                Console.WriteLine("Credenciales incorrectas");
            }
        }
    }
}
